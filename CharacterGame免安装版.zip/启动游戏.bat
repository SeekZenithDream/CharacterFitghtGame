@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"

if not exist "runtime\bin\java.exe" goto nore
if not exist "characterGame.jar" goto nojar

"runtime\bin\java.exe" -Dfile.encoding=UTF-8 -jar "characterGame.jar"

echo.
echo [CharacterGame closed] Press any key to exit...
pause >nul
exit /b 0

:nore
echo [ERROR] runtime\bin\java.exe not found.
echo Please keep the whole folder together and do not move files out of it.
pause
exit /b 1

:nojar
echo [ERROR] characterGame.jar not found.
pause
exit /b 1
